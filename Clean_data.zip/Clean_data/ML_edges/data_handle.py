import requests
import json
from datetime import datetime
import pickle
import pandas as pd
import schedule
import time
import get_temp
import time_s
URL = "http://127.0.0.1:8080/storage/log"

def dataHendal():

    with open("/home/pi/ML_Test/ML_edges/Data2.json", "r") as jfile:
        data1 = json.load(jfile)

    edge_active = len(data1["MIN_TEMPERATURE"])
    OutsiteT, wheather, Humidity = get_temp.getTemp("Mumbai", data1["Outside_Temp"], data1["Weather"], data1["Humidity"])
    S1, day = time_s.timeS(data1["s"], data1["Day"])
    try:
        json_edge = ["MIN_TEMPERATURE", "MAX_TEMPERATURE", "MIN_HUMIDITY", "MAX_HUMIDITY"]
        irPrameter = ["DI_ON_DURATION", "ON_DURATION"]
        list_IR = ["IR1", "IR2", "IR3"]
        Edge = []
        counter = 0
        r = requests.get(url=URL)
        data = str(r.json())
        rxData = json.loads(data)
        frxData = rxData['DATA']
        for key in frxData:
            edgeId = key.split(".")[0]
            if edgeId[0:4] == "EDGE":
                if edgeId not in Edge:
                    Edge.append(edgeId)


        for idx, edge_name in enumerate(Edge):
            for idx1, edge_value in enumerate(json_edge):  # for Temp & Humidity
                val = frxData['' + (edge_name) + '.' + (edge_value)] * 1000
                if (len(data1[edge_value]) > idx):
                    data1[edge_value][idx] = val
                else:
                    data1[edge_value].append(val)
            for irDureation in irPrameter:  # for IR Duration
                IRvalue1 = 0
                for ir in list_IR:
                    if frxData['' + (edge_name) + '.' + (ir) + '.' + irDureation + ''] != 0:
                        IRvalue = frxData['' + (edge_name) + '.' + (ir) + '.' + irDureation + '']
                        IRvalue1 = IRvalue1 + IRvalue
                        counter = counter + 1
                try:
                    avgIRvalue = (IRvalue1 / counter)*1000
                except:
                    avgIRvalue = IRvalue1*1000
                if (len(data1[irDureation]) > idx):
                    data1[irDureation][idx] = avgIRvalue
                    data1["Humidity"][idx] = Humidity
                    data1["Outside_Temp"][idx] = OutsiteT
                    data1["Weather"][idx] = wheather
                    data1["s"][idx] = S1
                    data1["Day"][idx] = day
                else:
                    data1[irDureation].append(avgIRvalue)
                    data1["Humidity"].append(Humidity)
                    data1["Outside_Temp"].append(OutsiteT)
                    data1["Weather"].append(wheather)
                    data1["s"].append(S1)
                    data1["Day"].append(day)
                counter = 0


    except:
        for active_no in range(edge_active):
            data1["Humidity"][active_no] = Humidity
            data1["Outside_Temp"][active_no] = OutsiteT
            data1["Weather"][active_no] = wheather
            data1["s"][active_no] = S1
            data1["Day"][active_no] = day

    with open("/home/pi/ML_Test/ML_edges/Data2.json", "w") as data2:
        json.dump(data1, data2)
    # print(data1)
    return data1,Edge
    
