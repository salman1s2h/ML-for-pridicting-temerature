import requests
import json
from datetime import datetime
import pickle
import pandas as pd
import schedule
import time
def getTemp(city,temp,weathear,humidity):
    weather = 0
    try:
        api_key = "4b184c31934edcea520a3990cd0da723"
        base_url = "http://api.openweathermap.org/data/2.5/weather?"
        city_name = city#city[city]  # input("Enter city name : ")
        complete_url = base_url + "appid=" + api_key + "&q=" + city_name
        # get method of requests module
        # return response object
        response = requests.get(complete_url)
        x = response.json()
        # print(x['main'])
        if x["cod"] != "404":
            y = x["main"]
            current_temperature = y["temp"]
            current_pressure = y["pressure"]
            current_humidiy = y["humidity"]
            z = x["weather"]
            weather_description = z[0]["description"]
            temp1 = round((current_temperature-(273.15))*1000)
            weather1 = WeatherState(weather_description)
            humidity1 = round(current_humidiy*1000)
            #print("__________________{}____________________________".format(humidity1))
            return temp1,weather1,humidity1
        else:
            return temp[0],weathear[0],humidity[0]
    except:
        return temp[0],weathear[0],humidity[0]