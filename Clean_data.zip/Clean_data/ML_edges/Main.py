from collections import namedtuple
from os import path
import schedule
import Weather_State
import get_temp
import time_s
import data_handle
import ML_module
import Post_Temp
import time
if __name__ == "__main__": 
	Post_Temp.PostTemp()
	schedule.every(30).minutes.do(Post_Temp.PostTemp)
	while True: 
		schedule.run_pending() 
		time.sleep(1) 
    