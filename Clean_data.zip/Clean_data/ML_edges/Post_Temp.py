import requests
import json
from datetime import datetime
import pickle
import pandas as pd
import schedule
import time
import data_handle
import ML_module



def PostTemp():
    try:
        URL = 'http://127.0.0.1:8080/config'
        now = datetime.now()
        timestamp = now.strftime('%Y%m%d%H%M%S')
        Edge_Data ,Active_Edge = data_handle.dataHendal()
        Value = ML_module.Ml_module()
        for idx,edge_id in enumerate(Active_Edge):
            ML_Setpoint = (Value[idx])/1000
            print(ML_Setpoint)
            payload = {"MODULE": "INPUT","DATA": {"KEY": ''+(edge_id)+'.SET_POINTS.TEMPERATURE',"VALUE": round(ML_Setpoint,1),"timestamp": timestamp}}
            print(payload)
            response = requests.post(URL, json=payload)
            json_data = response.json()
            print(response.text)
            print(response.status_code)
            time.sleep(2)

    except:
        print("No Communication. Please check network")

# def PostTemp():
#     try:
#         URL = 'http://127.0.0.1:8080/config'
#         now = datetime.now()
#         timestamp = now.strftime('%Y%m%d%H%M%S')
#         print(timestamp)
#         Value = ML_module.Ml_module()
#         Edge_Active = len(Value)
#         for Edge_No in range(Edge_Active):
#             ML_Setpoint = (Value[Edge_No])/1000
#             Edge_Id = Edge_No+1
#             print(ML_Setpoint)
#             payload = {"MODULE": "INPUT","DATA": {"KEY": 'EDGE'+str(Edge_Id)+'.SET_POINTS.TEMPERATURE',"VALUE": round(ML_Setpoint,1),"timestamp": timestamp}}
#             print(payload)
#             response = requests.post(URL, json=payload)
#             json_data = response.json()
#             print(response.text)
#             print(response.status_code)
#             time.sleep(2)
#     except:
#         print("No Communication. Please check network")
