import requests
import json
from datetime import datetime
import pickle
import pandas as pd
import schedule
import time
def timeS(s1,day1):
    try:
        now = datetime.now()
        s = int(now.strftime("%H%M"))
        days = now.strftime("%A")
        daylist = ["monday","tuesday","wednesday","thursday","friday","saturday","sunday"]
        day =daylist.index(days.lower())
        return s,day
    except:
        return s1[0],day1[0]
