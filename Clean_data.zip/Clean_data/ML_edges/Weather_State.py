def WeatherState(weath):
    weather = 0
    if (weath == "clear sky"):
        weather = 0
        return weather
    elif (weath == "few clouds"):
        weather = 1
        return weather
    elif(weath == "scattered clouds"):
        weather = 2
        return weather
    elif(weath == "broken clouds"):
        weather = 3
        return weather
    elif (weath == "few clouds"):
        weather = 4
        return weather
    elif(weath == "shower rain"):
        weather = 5
        return weather
    elif(weath == "	rain"):
        weather = 6
        return weather
    elif(weath == "thunderstorm"):
        weather = 7
        return weather
    elif(weath == "snow"):
        weather = 8
        return weather
    elif(weath == "mist"):
        weather = 9
        return weather
    else:
        return weather