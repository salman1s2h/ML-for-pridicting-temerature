import requests
import json
from datetime import datetime
import pickle
import pandas as pd
import schedule
import data_handle
import time
def Ml_module():
    Edge_Data ,Active_Edge = data_handle.dataHendal()
    X_test = pd.DataFrame(Edge_Data)
    print(X_test)
    filename = 'pickle3.5.pkl'
    filename_pkl_open = open(filename, 'rb')
    filename_pkl_model = pickle.load(filename_pkl_open)
    # print("Loaded Decision tree model :: ", filename_pkl_model)
    print('------------------------------ OUT PUT--------------------------------------------')
    output = filename_pkl_model.predict(X_test.fillna(0))
    print(output)
    return output

